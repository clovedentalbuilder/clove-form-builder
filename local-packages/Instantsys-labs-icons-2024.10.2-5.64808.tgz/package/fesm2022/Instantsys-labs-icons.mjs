import * as i0 from '@angular/core';
import { Component, Input } from '@angular/core';

class IconsComponent {
    constructor() {
        this._class = '';
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IconsComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.12", type: IconsComponent, isStandalone: true, selector: "icon", inputs: { _class: ["class", "_class"] }, ngImport: i0, template: `
    <i [class]="_class"></i>
  `, isInline: true, styles: [""] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.12", ngImport: i0, type: IconsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'icon', standalone: true, imports: [], template: `
    <i [class]="_class"></i>
  ` }]
        }], propDecorators: { _class: [{
                type: Input,
                args: ["class"]
            }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { IconsComponent };
//# sourceMappingURL=Instantsys-labs-icons.mjs.map
