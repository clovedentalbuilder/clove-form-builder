import * as i0 from "@angular/core";
export declare class IconsComponent {
    _class: string;
    static ɵfac: i0.ɵɵFactoryDeclaration<IconsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<IconsComponent, "icon", never, { "_class": { "alias": "class"; "required": false; }; }, {}, never, never, true, never>;
}
