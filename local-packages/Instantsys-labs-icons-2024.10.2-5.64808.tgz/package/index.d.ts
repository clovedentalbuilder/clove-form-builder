/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="@Instantsys-labs/icons" />
export * from './public-api';
